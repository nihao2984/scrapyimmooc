'pair tests'
